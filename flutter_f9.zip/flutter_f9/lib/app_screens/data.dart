List<String> images = [
  "images/fruit.jpg",
  "images/salad.jpg",
  "images/boiled.jpg",
  "images/chicken salad.jpg",
  "images/grilled fish.jpg",
  "images/chicken salami.jpg"
];

List<String> title = [
  "FRUIT SANDWHICH-Contains high fibre and vitamins\n",
  "FRUIT SALAD-Low fat,Rich in vitamins and dietary fibre",
  "BOILED VEGETABLES-Vitamin C and folate",
  "CHICKEN SALAD AND BREAST-Rich in calcium and protein",
  "GRILLED FISH-Low calorie protein",
  "CHICKEN SALAMI AND LAMB-Rich in fat and protein"
];
